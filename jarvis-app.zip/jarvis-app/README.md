# Jarvis AI Pro — File Structure

Aapka app pehle 1 hi bade `index.html` file (2200+ lines) mein tha.
Ab wahi poora app 13 chote, samajhne-mein-aasan files mein baant diya
gaya hai — koi feature nahi hataya gaya, sirf organize kiya gaya hai.

## Folder structure

```
jarvis-app/
├── index.html              (sirf HTML markup — 326 lines)
├── service-worker.js        (PWA offline caching)
├── css/
│   └── styles.css           (saara styling — 241 lines)
└── js/
    ├── config.js             (API URL, Firebase config, global state variables)
    ├── utils.js              (chhote helper functions — escapeHtml, showToast, etc)
    ├── firebase.js            (cloud sync — Firestore mein chat/settings save karna)
    ├── settings.js            (theme + settings panel load/save)
    ├── ui.js                  (sidebar, tabs, header back-button navigation)
    ├── chat-render.js         (message bubbles, markdown, typing animation)
    ├── history.js             (chat history sessions, export PDF/text)
    ├── gallery.js             (generated images gallery)
    ├── voice.js                (voice input + live voice chat mode)
    ├── image.js                (photo upload, compression, AI image analysis)
    ├── chat-engine.js          (asli AI se baat karne wala core logic — sabse zaroori file)
    └── auth.js                 (login/signup/Google sign-in/guest mode)
```

## Isse kya fayda hua

- **Bug dhoondhna aasan**: Agar voice mein problem hai, to sirf
  `js/voice.js` dekhna hai — 2000 line mein dhundhna nahi padega.
- **Naya feature add karna aasan**: Jaise agar "reminders" feature
  add karna ho, to ek nayi `js/reminders.js` file bana kar
  `index.html` mein ek line jodni hai.
- **Kaam badalne se kuch nahi tootega**: Har file apna kaam karti
  hai — settings badalne se chat-engine pe asar nahi padega.

## Deploy kaise karein

Poora `jarvis-app/` folder waise ka waisa apni hosting (GitHub
Pages, Netlify, Firebase Hosting, waghera) pe upload kar do —
folder structure (css/, js/ subfolders) same rakhna zaroori hai,
warna files load nahi hongi.

Functionality mein **koi change nahi hai** — sab kuch pehle jaisa
hi chalega, bas code ab saaf-suthra aur maintain karne layak hai.
